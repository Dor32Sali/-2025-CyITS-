const API_BASE = "http://localhost:5000";

async function handleResponse(res) {
  const contentType = res.headers.get("content-type") || "";
  let body = null;
  if (contentType.includes("application/json")) {
    body = await res.json();
  } else {
    const text = await res.text();
    body = { raw: text };
  }

  if (!res.ok) {
    const err = new Error(body && body.error ? body.error : "Request failed");
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return body;
}

export async function fetchStatus() {
  const res = await fetch(`${API_BASE}/status`);
  return handleResponse(res);
}

export async function fetchAlerts() {
  const res = await fetch(`${API_BASE}/alerts`);
  return handleResponse(res);
}

export async function simulateAttack(intersectionId, attackType) {
  const res = await fetch(`${API_BASE}/simulate-attack`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ intersection_id: intersectionId, attack_type: attackType }),
  });
  return handleResponse(res);
}
