// Pure React-side simulation engine: intersections state, risk engine and event log

const INITIAL_INTERSECTIONS = [
  { id: "I1", status: "normal", traffic_load: 15, risk_score: "low" },
  { id: "I2", status: "normal", traffic_load: 30, risk_score: "low" },
  { id: "I3", status: "normal", traffic_load: 45, risk_score: "low" },
  { id: "I4", status: "normal", traffic_load: 20, risk_score: "low" },
  { id: "I5", status: "normal", traffic_load: 60, risk_score: "medium" },
  { id: "I6", status: "normal", traffic_load: 75, risk_score: "medium" },
  { id: "I7", status: "normal", traffic_load: 10, risk_score: "low" },
  { id: "I8", status: "normal", traffic_load: 35, risk_score: "low" },
  { id: "I9", status: "normal", traffic_load: 50, risk_score: "medium" }
];

function baseRiskFromStatus(status) {
  if (status === "under_attack") return "high";
  if (status === "suspicious") return "medium";
  return "low";
}

function riskFromAttackType(attackType) {
  const high = ["SENSOR_SPOOFING", "TRAFFIC_LIGHT_MANIPULATION"];
  const medium = ["FALSE_EMERGENCY_VEHICLE", "TRAFFIC_LOAD_SPOOFING"];
  if (high.includes(attackType)) return "high";
  if (medium.includes(attackType)) return "medium";
  return "low";
}

function evaluateIntersection(intersection) {
  const updated = { ...intersection };
  let risk = baseRiskFromStatus(updated.status || "normal");
  const load = updated.traffic_load ?? 0;
  if (load >= 80) risk = "high";
  else if (load >= 50 && risk === "low") risk = "medium";
  updated.risk_score = risk;
  return updated;
}

function recalcAll(intersections) {
  return intersections.map((i) => evaluateIntersection(i));
}

function nowTimeString() {
  const d = new Date();
  const pad = (n) => (n < 10 ? `0${n}` : `${n}`);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

export function createInitialSimulationState() {
  return {
    intersections: recalcAll(INITIAL_INTERSECTIONS),
    events: []
  };
}

export function simulateAttackOnState(state, intersectionId, attackType) {
  const intersections = state.intersections.map((i) => ({ ...i }));
  const idx = intersections.findIndex((i) => i.id === intersectionId);
  if (idx === -1) {
    throw new Error(`Unknown intersection_id: ${intersectionId}`);
  }

  const target = intersections[idx];
  let message = "";
  const riskLevel = riskFromAttackType(attackType);

  if (attackType === "SENSOR_SPOOFING") {
    target.status = "under_attack";
    target.traffic_load = Math.min(100, (target.traffic_load || 0) + 40);
    message = "Sensor readings inconsistent with historical patterns";
  } else if (attackType === "FALSE_EMERGENCY_VEHICLE") {
    target.status = "suspicious";
    target.traffic_load = Math.max(0, (target.traffic_load || 0) - 10);
    message = "Conflicting emergency vehicle preemption requests detected";
  } else if (attackType === "TRAFFIC_LOAD_SPOOFING") {
    target.status = "suspicious";
    target.traffic_load = Math.min(100, (target.traffic_load || 0) + 25);
    message = "Reported volume does not match sensor fusion estimate";
  } else if (attackType === "TRAFFIC_LIGHT_MANIPULATION") {
    target.status = "under_attack";
    target.traffic_load = Math.min(100, (target.traffic_load || 0) + 30);
    message = "Unauthorized phase change patterns detected";
  } else {
    throw new Error(`Unsupported attack_type: ${attackType}`);
  }

  intersections[idx] = evaluateIntersection(target);

  const updatedOthers = intersections.map((i) => {
    if (i.id === intersectionId) return i;
    const copy = { ...i };
    if (copy.status !== "normal") {
      copy.status = "suspicious";
    }
    copy.traffic_load = Math.max(0, (copy.traffic_load || 0) - 2);
    return evaluateIntersection(copy);
  });

  const event = {
    timestamp: nowTimeString(),
    intersection_id: intersectionId,
    event_type: attackType,
    risk_level: riskLevel,
    message
  };

  const newEvents = [event, ...state.events].slice(0, 500);

  return {
    intersections: updatedOthers,
    events: newEvents,
    generated_events: [event]
  };
}

export function tickState(state) {
  // Optional passive dynamics on each 15s tick: small drift toward normal.
  const intersections = state.intersections.map((i) => {
    const copy = { ...i };
    if (copy.status === "under_attack") {
      // keep under_attack but slowly reduce load
      copy.traffic_load = Math.max(0, (copy.traffic_load || 0) - 1);
    } else if (copy.status === "suspicious") {
      copy.traffic_load = Math.max(0, (copy.traffic_load || 0) - 1);
      if (copy.traffic_load < 30) {
        copy.status = "normal";
      }
    }
    return evaluateIntersection(copy);
  });

  return {
    ...state,
    intersections
  };
}
