import React, { useEffect, useState, useCallback } from "react";
import IntersectionMap from "./components/IntersectionMap";
import AttackControls from "./components/AttackControls";
import EventFeed from "./components/EventFeed";
import SystemStatus from "./components/SystemStatus";
import IntersectionDetails from "./components/IntersectionDetails";
import {
  createInitialSimulationState,
  simulateAttackOnState,
  tickState,
} from "./services/simulationEngine";
import "./styles/Components.css";

const REFRESH_MS = 15000;

function App() {
  const [intersections, setIntersections] = useState([]);
  const [events, setEvents] = useState([]);
  const [selectedIntersectionId, setSelectedIntersectionId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Initialize local simulation state once
  useEffect(() => {
    const initial = createInitialSimulationState();
    setIntersections(initial.intersections);
    setEvents(initial.events);
    if (initial.intersections.length > 0) {
      setSelectedIntersectionId(initial.intersections[0].id);
    }
  }, []);

  // Passive dynamics tick every REFRESH_MS (15s), like auto-refresh
  const tick = useCallback(() => {
    setIntersections((prevIntersections) => {
      const currentState = { intersections: prevIntersections, events };
      const nextState = tickState(currentState);
      // events are unchanged by tickState currently
      return nextState.intersections;
    });
  }, [events]);

  useEffect(() => {
    const interval = setInterval(tick, REFRESH_MS);
    return () => clearInterval(interval);
  }, [tick]);

  const handleAttackTrigger = async (intersectionId, attackType) => {
    setLoading(true);
    setError(null);
    try {
      setIntersections((prevIntersections) => {
        const currentState = {
          intersections: prevIntersections,
          events,
        };
        const nextState = simulateAttackOnState(
          currentState,
          intersectionId,
          attackType
        );
        setEvents(nextState.events);
        return nextState.intersections;
      });
    } catch (err) {
      console.error("Failed to simulate attack", err);
      setError("Attack simulation failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleIntersectionSelect = (id) => {
    setSelectedIntersectionId(id);
  };

  const selectedIntersection =
    intersections.find((i) => i.id === selectedIntersectionId) || null;

  return (
    <div className="app-root">
      <header className="app-header">
        <div>
          <h1>Smart Intersection Cyber Defense Dashboard</h1>
          <p className="subtitle">
            Real-time monitoring, cyber-attack simulation, and automated response
            visualization.
          </p>
        </div>
        <SystemStatus intersections={intersections} lastError={error} />
      </header>

      <main className="app-main">
        <section className="left-column">
          <IntersectionMap
            intersections={intersections}
            selectedId={selectedIntersectionId}
            onSelect={handleIntersectionSelect}
          />
          <AttackControls
            intersections={intersections}
            selectedId={selectedIntersectionId}
            onTriggerAttack={handleAttackTrigger}
            loading={loading}
          />
        </section>

        <section className="right-column">
          <IntersectionDetails intersection={selectedIntersection} />
          <EventFeed events={events} />
        </section>
      </main>

      {error && <div className="error-banner">{error}</div>}
    </div>
  );
}

export default App;
