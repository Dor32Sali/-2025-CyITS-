import React from "react";

const statusToClass = (status) => {
  switch (status) {
    case "under_attack":
      return "intersection under-attack";
    case "suspicious":
      return "intersection suspicious";
    case "normal":
    default:
      return "intersection normal";
  }
};

function IntersectionMap({ intersections, selectedId, onSelect }) {
  return (
    <div className="panel">
      <div className="panel-header">
        <h2>Intersection Grid</h2>
        <span className="panel-subtitle">Click an intersection to inspect</span>
      </div>
      <div className="intersection-grid">
        {intersections.map((intersection) => {
          const cls = statusToClass(intersection.status);
          const isSelected = intersection.id === selectedId;
          return (
            <button
              key={intersection.id}
              className={`${cls} ${isSelected ? "selected" : ""}`}
              onClick={() => onSelect(intersection.id)}
            >
              <div className="intersection-id">{intersection.id}</div>
              <div className="intersection-load">
                Load: {intersection.traffic_load}
              </div>
              <div className={`intersection-risk risk-${intersection.risk_score}`}>
                Risk: {intersection.risk_score}
              </div>
            </button>
          );
        })}
        {intersections.length === 0 && (
          <div className="empty-placeholder">No intersections available.</div>
        )}
      </div>
    </div>
  );
}

export default IntersectionMap;
