import React, { useMemo } from "react";

function SystemStatus({ intersections, lastError }) {
  const summary = useMemo(() => {
    const total = intersections.length;
    let underAttack = 0;
    let suspicious = 0;
    let normal = 0;

    intersections.forEach((i) => {
      if (i.status === "under_attack") underAttack += 1;
      else if (i.status === "suspicious") suspicious += 1;
      else normal += 1;
    });

    return { total, underAttack, suspicious, normal };
  }, [intersections]);

  return (
    <div className="system-status">
      <div className="status-item">
        <span className="status-label">Total</span>
        <span className="status-value">{summary.total}</span>
      </div>
      <div className="status-item status-normal">
        <span className="status-label">Normal</span>
        <span className="status-value">{summary.normal}</span>
      </div>
      <div className="status-item status-suspicious">
        <span className="status-label">Suspicious</span>
        <span className="status-value">{summary.suspicious}</span>
      </div>
      <div className="status-item status-attack">
        <span className="status-label">Under Attack</span>
        <span className="status-value">{summary.underAttack}</span>
      </div>
      {lastError && <div className="status-error">{lastError}</div>}
    </div>
  );
}

export default SystemStatus;
