import React, { useState, useEffect } from "react";

const ATTACK_TYPES = [
  { value: "SENSOR_SPOOFING", label: "Sensor Spoofing" },
  { value: "FALSE_EMERGENCY_VEHICLE", label: "False Emergency Vehicle" },
  { value: "TRAFFIC_LOAD_SPOOFING", label: "Traffic Load Spoofing" },
  { value: "TRAFFIC_LIGHT_MANIPULATION", label: "Traffic Light Manipulation" },
];

function AttackControls({ intersections, selectedId, onTriggerAttack, loading }) {
  const [intersectionId, setIntersectionId] = useState(selectedId || "");
  const [attackType, setAttackType] = useState(ATTACK_TYPES[0].value);

  useEffect(() => {
    if (selectedId) {
      setIntersectionId(selectedId);
    }
  }, [selectedId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!intersectionId || !attackType || loading) return;
    onTriggerAttack(intersectionId, attackType);
  };

  return (
    <div className="panel">
      <div className="panel-header">
        <h2>Attack Simulation Panel</h2>
        <span className="panel-subtitle">
          Choose an intersection and attack type, then trigger simulation.
        </span>
      </div>
      <form className="attack-form" onSubmit={handleSubmit}>
        <div className="form-row">
          <label htmlFor="intersection-select">Intersection</label>
          <select
            id="intersection-select"
            value={intersectionId}
            onChange={(e) => setIntersectionId(e.target.value)}
          >
            <option value="" disabled>
              Select intersection
            </option>
            {intersections.map((i) => (
              <option key={i.id} value={i.id}>
                {i.id} (load {i.traffic_load}, risk {i.risk_score})
              </option>
            ))}
          </select>
        </div>

        <div className="form-row">
          <label htmlFor="attack-select">Attack type</label>
          <select
            id="attack-select"
            value={attackType}
            onChange={(e) => setAttackType(e.target.value)}
          >
            {ATTACK_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          className="primary-btn"
          disabled={!intersectionId || loading}
        >
          {loading ? "Simulating..." : "Trigger Attack"}
        </button>
      </form>
    </div>
  );
}

export default AttackControls;
