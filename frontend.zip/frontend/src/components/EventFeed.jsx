import React from "react";

const riskToClass = (risk) => {
  switch (risk) {
    case "high":
      return "risk-pill risk-high";
    case "medium":
      return "risk-pill risk-medium";
    case "low":
    default:
      return "risk-pill risk-low";
  }
};

function EventFeed({ events }) {
  return (
    <div className="panel event-feed">
      <div className="panel-header">
        <h2>Event Feed</h2>
        <span className="panel-subtitle">
          Latest cyber and traffic anomalies ordered by time.
        </span>
      </div>
      <div className="event-list">
        {events.length === 0 && (
          <div className="empty-placeholder">No events yet. System is stable.</div>
        )}
        {events.map((e) => (
          <div key={`${e.timestamp}-${e.intersection_id}-${e.event_type}`} className="event-item">
            <div className="event-meta">
              <span className="event-time">{e.timestamp}</span>
              <span className="event-intersection">{e.intersection_id}</span>
              <span className="event-type">{e.event_type}</span>
              <span className={riskToClass(e.risk_level)}>{e.risk_level}</span>
            </div>
            <div className="event-message">{e.message}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default EventFeed;
