import React from "react";

function IntersectionDetails({ intersection }) {
  if (!intersection) {
    return (
      <div className="panel">
        <div className="panel-header">
          <h2>Intersection Details</h2>
        </div>
        <div className="panel-body empty-placeholder">
          Select an intersection to view telemetry and risk details.
        </div>
      </div>
    );
  }

  return (
    <div className="panel">
      <div className="panel-header">
        <h2>Intersection {intersection.id}</h2>
        <span className="panel-subtitle">Live telemetry and cyber risk profile</span>
      </div>
      <div className="panel-body intersection-details-body">
        <div className="detail-row">
          <span className="detail-label">Status</span>
          <span className={`detail-value status-pill status-${intersection.status}`}>
            {intersection.status}
          </span>
        </div>
        <div className="detail-row">
          <span className="detail-label">Traffic load</span>
          <span className="detail-value">{intersection.traffic_load}</span>
        </div>
        <div className="detail-row">
          <span className="detail-label">Risk score</span>
          <span className={`detail-value risk-pill risk-${intersection.risk_score}`}>
            {intersection.risk_score}
          </span>
        </div>
      </div>
    </div>
  );
}

export default IntersectionDetails;
